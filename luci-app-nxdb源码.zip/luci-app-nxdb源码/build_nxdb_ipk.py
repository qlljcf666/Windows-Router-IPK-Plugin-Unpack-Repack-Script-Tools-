# -*- coding: utf-8 -*-
"""把 CONTROL/ + root/ 组装成 luci-app-nxdb_<ver>_all.ipk (跨平台, 纯文本资源)"""
import os, sys, io as _io, tarfile

HERE = os.path.dirname(os.path.abspath(__file__))
CTRL = os.path.join(HERE, "CONTROL")
ROOT = os.path.join(HERE, "root")


def read_control_meta():
    meta = {}
    with open(os.path.join(CTRL, "control"), "r", encoding="utf-8", newline="") as f:
        for line in f:
            if ":" in line and not line.startswith(" "):
                k, v = line.split(":", 1)
                meta[k.strip()] = v.strip()
    return meta


def add_bytes(tar, arc, data, mode):
    ti = tarfile.TarInfo(arc)
    ti.size = len(data)
    ti.mode = mode
    ti.mtime = 0
    ti.uid = ti.gid = 0
    ti.uname = ti.gname = "root"
    tar.addfile(ti, _io.BytesIO(data))


def add_file(tar, src, arc, mode):
    ti = tarfile.TarInfo(arc)
    ti.size = os.path.getsize(src)
    ti.mode = mode
    ti.mtime = 0
    ti.uid = ti.gid = 0
    ti.uname = ti.gname = "root"
    with open(src, "rb") as f:
        tar.addfile(ti, f)


def add_dir(tar, arc):
    ti = tarfile.TarInfo(arc.rstrip("/") + "/")
    ti.type = tarfile.DIRTYPE
    ti.mode = 0o755
    ti.mtime = 0
    tar.addfile(ti)


def write_ipk(path, members):
    """ipk = 外层 gzip tar (OpenWrt 官方格式), 成员: ./debian-binary ./data.tar.gz ./control.tar.gz
    注意: 不能用 ar 归档, 本固件 opkg 只接受 tar.gz 格式。"""
    with tarfile.open(path, "w:gz", format=tarfile.GNU_FORMAT, compresslevel=9) as t:
        for name, data in members:
            ti = tarfile.TarInfo("./" + name)
            ti.size = len(data)
            ti.mode = 0o644
            ti.mtime = 0
            ti.uid = ti.gid = 0
            ti.uname = ti.gname = "root"
            t.addfile(ti, _io.BytesIO(data))


def main():
    meta = read_control_meta()
    pkg, ver, arch = meta["Package"], meta["Version"], meta["Architecture"]
    assert arch == "all", "luci-app-nxdb 必须是架构无关包"

    exec_names = {"preinst", "postinst", "prerm", "postrm"}

    # control.tar.gz
    cbuf = _io.BytesIO()
    with tarfile.open(fileobj=cbuf, mode="w:gz", compresslevel=9) as t:
        for name in sorted(os.listdir(CTRL)):
            src = os.path.join(CTRL, name)
            if not os.path.isfile(src):
                continue
            mode = 0o755 if name in exec_names else 0o644
            add_file(t, src, "./" + name, mode)
    control_tgz = cbuf.getvalue()

    # data.tar.gz
    dbuf = _io.BytesIO()
    dirs_added = set()
    with tarfile.open(fileobj=dbuf, mode="w:gz", compresslevel=9) as t:
        for base, dirs, files in os.walk(ROOT):
            rel_dir = os.path.relpath(base, ROOT).replace(os.sep, "/")
            if rel_dir != ".":
                add_dir(t, "./" + rel_dir)
            for fn in sorted(files):
                src = os.path.join(base, fn)
                rel = os.path.relpath(src, ROOT).replace(os.sep, "/")
                mode = 0o755 if fn.endswith(".sh") else 0o644
                add_file(t, src, "./" + rel, mode)
    data_tgz = dbuf.getvalue()

    out = os.path.join(os.path.dirname(HERE), "%s_%s_%s.ipk" % (pkg, ver, arch))
    write_ipk(out, [
        ("debian-binary", b"2.0\n"),
        ("data.tar.gz", data_tgz),
        ("control.tar.gz", control_tgz),
    ])
    print("built:", out, os.path.getsize(out), "bytes")


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    main()
